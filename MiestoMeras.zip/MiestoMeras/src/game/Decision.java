package game;
public class Decision {
    private final String name;
    private final double happinessChange;
    private final double safetyChange;
    private final double environmentChange;
    private final double budgetChange;
    public Decision(String name, double happinessChange, double safetyChange,
                    double environmentChange, double budgetChange) {
        this.name = name;
        this.happinessChange = happinessChange;
        this.safetyChange = safetyChange;
        this.environmentChange = environmentChange;
        this.budgetChange = budgetChange;
    }
    public String getName() { return name; }
    public double getHappinessChange() { return happinessChange; }
    public double getSafetyChange() { return safetyChange; }
    public double getEnvironmentChange() { return environmentChange; }
    public double getBudgetChange() { return budgetChange; }
}
