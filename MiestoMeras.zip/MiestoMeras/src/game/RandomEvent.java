package game;
import java.util.Random;
public class RandomEvent {
    private final String description;
    private final double budgetEffect;
    private final double happinessEffect;
    public RandomEvent(String description, double budgetEffect, double happinessEffect) {
        this.description = description;
        this.budgetEffect = budgetEffect;
        this.happinessEffect = happinessEffect;
    }
    public static RandomEvent random() {
        Random r = new Random();
        int roll = r.nextInt(3);
        return switch (roll) {
            case 0 -> new RandomEvent("Gaisras miesto centre", -2000, -5);
            case 1 -> new RandomEvent("Protestas del mokescių", 0, -8);
            default -> new RandomEvent("Turizmo bumas !", +3000, +6);
        };
    }
    public String getDescription() { return description; }
    public double getBudgetEffect() { return budgetEffect; }
    public double getHappinessEffect() { return happinessEffect; }
}
