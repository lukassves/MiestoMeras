package game;

import java.util.Random;
import java.util.Scanner;

public class GameLoop {
    private final City city;
    private final GameStrategy strategy;
    private final Scanner scanner = new Scanner(System.in);
    private final Random random = new Random();

    public GameLoop(City city, GameStrategy strategy) {
        this.city = city;
        this.strategy = strategy;
    }

    public void start() {
        System.out.println("Sveikas atvykes į Miesto Mero zaidima!");
        int turn = 1;
        while (true) {
            System.out.println("\n======Ejimas " + turn + " ======");
            city.printStatus();
            System.out.println("Pasirink veiksma:");
            System.out.println("1. Statyti parką");
            System.out.println("2. Statyti policijos nuovadą");
            System.out.println("3. Didinti mokesčius");
            System.out.println("4. Nieko nedaryti");
            System.out.print("->  ");
            int choice = scanner.nextInt();
            Decision decision = DecisionFactory.createDecision(choice);
            city.applyDecision(decision);
            if (random.nextDouble() < strategy.getRandomEventChance()) {
                RandomEvent event = RandomEvent.random();
                city.applyRandomEvent(event);
            }
            if (city.isBankrupt()) {
                System.out.println("Miestas bankrutavo!");
                break;
            }
            if (city.isUnhappy()) {
                System.out.println("Gyventojai per nelaimingi!");
                break;
            }

            if (turn >= strategy.getTargetTurns()) {
                System.out.println("Miestas išgyveno visus ejimus! Laimėjai!");
                break;
            }

            turn++;
        }

        System.out.println("Žaidimo pabaiga. Ačiū, Mere!");
    }
}
