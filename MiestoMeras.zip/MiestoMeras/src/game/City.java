package game;
public class City {
    private int population;
    private double happiness;
    private double safety;
    private double environment;
    private double budget;
    public City(int population, double happiness, double safety, double environment, double budget) {
        this.population = population;
        this.happiness = happiness;
        this.safety = safety;
        this.environment = environment;
        this.budget = budget;
    }
    public void applyDecision(Decision d) {
        budget += d.getBudgetChange();
        happiness += d.getHappinessChange();
        safety += d.getSafetyChange();
        environment += d.getEnvironmentChange();
    }
    public void applyRandomEvent(RandomEvent e) {
        System.out.println("Įvykis: " + e.getDescription());
        budget += e.getBudgetEffect();
        happiness += e.getHappinessEffect();
    }
    public boolean isBankrupt() { return budget <= 0; }
    public boolean isUnhappy() { return happiness <= 0; }
    public void printStatus() {
        System.out.println("Miesto būsena:");
        System.out.printf("Gyventojai: %d | Laimė: %.1f | Saugumas: %.1f | Aplinka: %.1f | Biudžetas: %.1f €\n",
                population, happiness, safety, environment, budget);
    }
    public double getBudget() { return budget; }
    public double getHappiness() { return happiness; }
    public void setBudget(double budget) { this.budget = budget; }
    public void setHappiness(double happiness) { this.happiness = happiness; }
}
