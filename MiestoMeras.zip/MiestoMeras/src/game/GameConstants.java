package game;
public interface GameConstants
{
    int NORMAL_TURNS = 10;
    int HARD_TURNS = 15;
    double NORMAL_EVENT_CHANCE = 0.3;
    double HARD_EVENT_CHANCE = 0.6;
}
