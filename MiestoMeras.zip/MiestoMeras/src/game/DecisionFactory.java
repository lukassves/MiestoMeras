package game;

public class DecisionFactory
{
    public static Decision createDecision(int choice)
    {
        return switch (choice)
        {
            case 1 -> new Decision("Parkas", +5, 0, +5, -2000);
            case 2 -> new Decision("Policija", 0, +5, 0, -3000);
            case 3 -> new Decision("Mokesčiai", -3, 0, 0, +2000);
            default -> new Decision("Nieko", 0, 0, 0, 0);
        };
    }
}
