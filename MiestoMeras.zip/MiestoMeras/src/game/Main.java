package game;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Pasirink sunkumo lygį:");
        System.out.println("1. Normalus");
        System.out.println("2. Sunkus");
        System.out.print("->  ");
        int choice = scanner.nextInt();
        GameStrategy mode = (choice == 2) ? new GameMode.Hard() : new GameMode.Normal();
        City city = new City(10000, 50, 50, 50, 10000);
        GameLoop game = new GameLoop(city, mode);
        game.start();
    }
}
