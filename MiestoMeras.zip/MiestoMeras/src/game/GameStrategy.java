package game;
public interface GameStrategy
{
    double getRandomEventChance();
    int getTargetTurns();
}
