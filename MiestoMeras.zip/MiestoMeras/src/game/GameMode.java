package game;
public class GameMode {
    public static class Normal implements GameStrategy {
        public double getRandomEventChance() { return 0.3; }
        public int getTargetTurns() { return 10; }
    }
    public static class Hard implements GameStrategy {
        public double getRandomEventChance() { return 0.6; }
        public int getTargetTurns() { return 15; }
    }
}
