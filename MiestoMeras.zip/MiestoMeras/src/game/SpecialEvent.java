package game;
public class SpecialEvent extends RandomEvent
{
    private String bonusMessage;
    public SpecialEvent(String name, int budgetEffect, int happinessEffect, String bonusMessage)
    {
        super(name, budgetEffect, happinessEffect);
        this.bonusMessage = bonusMessage;
    }
    @Override
    public void trigger(City city)
    {
        super.trigger(city);
        System.out.println("Special įvykis: " + bonusMessage);
    }
}
