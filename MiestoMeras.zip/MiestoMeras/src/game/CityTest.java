package game;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class CityTest {
    @Test
    public void testApplyDecisionAffectsBudget() {
        City city = new City(10000, 50, 50, 50, 10000);
        Decision decision = new Decision("Parkas", 0, 0, 0, -2000);
        city.applyDecision(decision);
        assertEquals(8000, city.getBudget(), 0.001);
    }
    @Test
    public void testApplyDecisionAffectsHappiness() {
        City city = new City(10000, 50, 50, 50, 10000);
        Decision decision = new Decision("Parkas", +5, 0, 0, 0);
        city.applyDecision(decision);
        assertTrue(city.getHappiness() > 50);
    }
}
