package game;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class CityTest
{
    @Test
    public void testApplyDecisionAffectsBudget()
    {
        City city = new City(10000, 50, 50, 50, 10000);
        Decision decision = new Decision("Parkas", 0, 0, 0, -2000);
        city.applyDecision(decision);
        assertEquals(8000, city.getBudget(), 0.001);
    }
    @Test
    public void testApplyDecisionAffectsHappiness()
    {
        City city = new City(10000, 50, 50, 50, 10000);
        Decision decision = new Decision("Parkas", +5, 0, 0, 0);
        city.applyDecision(decision);
        assertTrue(city.getHappiness() > 50);
    }
    @Test
    public void testCityBankruptcyCondition()
    {
        City city = new City(10000, 50, 50, 50, 100);
        Decision decision = new Decision("Didžiulė investicija", 0, 0, 0, -5000);
        city.applyDecision(decision);
        assertTrue(city.isBankrupt());
    }
    @Test
    public void testRandomEventReducesBudget()
    {
        City city = new City(10000, 50, 50, 50, 10000);
        RandomEvent event = new RandomEvent("Gaisras", -2000, -10);
        event.trigger(city);
        assertTrue(city.getBudget() < 10000);
    }
    @Test
    public void testHardModeHasMoreEvents()
    {
        GameStrategy hard = new GameMode.Hard();
        GameStrategy normal = new GameMode.Normal();
        assertTrue(hard.getRandomEventChance() > normal.getRandomEventChance());
    }
}
